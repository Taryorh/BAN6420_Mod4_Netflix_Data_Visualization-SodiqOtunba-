# Load libraries
library(ggplot2)

# Load the cleaned dataset
df <- read.csv("C:/Users/sodiq.otunba/Desktop/Interswitch code/NXU/MSDA/BAN6420/Module 4/Netflix_shows_movies.csv")


#Calling the library
ggplot(data = df, aes(x = rating)) +
  geom_bar() +
  labs(title = "Distribution of Ratings", x = "Rating", y = "Count") +
  theme_minimal()
